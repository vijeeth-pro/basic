import logo from './logo.svg';
import './App.css';  
import Name from './page/Name';
import { useEffect, useState } from 'react';
// jsx

function App() {
  const [name, updateName] = useState('vijeeth') // ['vijeeth', function]
  const [todo, setTodo] = useState(['todo1', 'todo2', 'todo3']) // ['vijeeth', function
  const [inputValue, setInputValue] = useState('') 
  
  const handleList = () => {
    setTodo([...todo, inputValue])
  }

  return (
    <div className='todo'>
      {/* {name}
      <button onClick={changeName}>Change Name</button> */}
      <input placeholder='list' onChange={(e) => setInputValue(e.target.value)}/>
      <button onClick={() => handleList()}>Add Todo</button>
      <ul>
        {todo.map((item, index) => <li key={index}>{item}</li>)}
      </ul>

    </div>  
  );    
}

export default App;