import React from 'react'

 function Name() {
  return (
    <div id='class'>
      vijeeth
    </div>
  )
}

export default Name